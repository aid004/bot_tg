import TelegramBot from "node-telegram-bot-api";
import express from "express";
import morgan from "morgan";
import https from "https";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();

export const bot_tg = new TelegramBot(process.env.API_KEY_BOT, {
  polling: {
    interval: 200,
    autoStart: true,
  },
});
export const app = express();

// export const registerSearch = asyncHandler(async (req, res) => {}

async function main() {
  app.use(morgan("tiny"));
  app.use(express.json());
  app.use(cors({ origin: "*" }));
  app.use(express.urlencoded({ extended: true }));
  //   app.use("/api/success-payment/", successPay);
  bot_tg.on("polling_error", (err) => console.log(err.data.error.message));
  app.listen(
    process.env.PORT,
    console.log(
      `🚀 Server and TG-bot running in ${process.env.NODE_ENV} mode on port ${process.env.PORT}`
    )
  );

  bot_tg.on("message", async (msg) => {
    if (msg.text === "/start") {
      await bot_tg.sendPhoto(msg.chat.id, "./public/main.jpg", {
        caption:
          "Привет\\! 👋\nЗдесь мы научим тебя создавать стильные бирки:\n✔️ *Печатать бирки для вещей и товаров*\\.\n✔️ *Настроить процесс* для заработка\\.\n✔️ *Прокачать свои вещи или бизнес без затрат*\\.\n\nУзнаешь:\n1️⃣ Как создать дизайн\\.\n2️⃣ Какие материалы и оборудование выбрать\\.\n3️⃣ Как печатать быстро и качественно\\.\n4️⃣ Как сделать из этого прибыльное дело\\.\n\nНачни свой путь к успеху уже сейчас\\!",
        parse_mode: "MarkdownV2",
      });
    }
    if (msg.text === "/oferta") {
      await bot_tg.sendMessage(
        msg.chat.id,
        "https://telegra.ph/Dogovor-oferty-12-11"
      );
    }
  });

  //   https
  //     .createServer(options, app)
  //     .listen(8443, console.log("https be started"));
}

await main();
//   .then(async () => {
//     await prisma.$disconnect();
//   })
//   .catch(async (e) => {
//     console.error(e);
//     await prisma.$disconnect();
//     process.exit(1);
//   });
